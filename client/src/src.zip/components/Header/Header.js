import React from "react";
import classes from "./Header.css"

const Header = (props) => {
    return(
        <div className={'header-block'}>
            <p>Lot-ToDo</p>
            <div>
                <button></button>
                <button></button>
                <button></button>
            </div>
        </div>
    )
}

export default Header;