import React from "react";
import classes from './Todo.module.css'

const Todo = (props) => (
    <div className={classes.Todo}>
        <li key={props.id} className={classes.todoItem}>{props.text}</li>
        <button key={props.id}>-</button>
    </div>
)

export default Todo;
