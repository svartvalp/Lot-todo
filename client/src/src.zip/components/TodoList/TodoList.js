import React from "react";
import Todo from "./Todo/Todo"
import classes from './TodoList.module.css'

const TodoList = (props) => {
    const content = [
        {id: 1, task: "Wash dishes"},
        {id: 2, task: "Make homework"},
        {id: 3, task: "Make program"},
    ]
    const list = content.map((cont, index) => {
            return (<Todo key={cont.id} text={cont.task} />)
        })

    return(
        <div className={classes.todoWrapper}>
            <ul className={classes.todoList}>
                {list}
            </ul>
        </div>
    )
}

export default TodoList;