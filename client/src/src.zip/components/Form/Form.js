import React from "react";
import classes from './Form.module.css'

const Form = (props) => {
    return (
        <form className={classes.Form}>
            <input className={classes.InputForm}/>
            <button className={classes.SubmitButton} type='submit'><i>+</i></button>
        </form>
    )
}

export default Form;